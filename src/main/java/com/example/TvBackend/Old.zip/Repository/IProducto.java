package com.example.TvBackend.Repository;

import com.example.TvBackend.Model.Producto;
import org.springframework.data.repository.CrudRepository;

public interface IProducto  extends CrudRepository<Producto,Integer>{

}
