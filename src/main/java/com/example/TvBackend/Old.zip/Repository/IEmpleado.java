package com.example.TvBackend.Repository;
import com.example.TvBackend.Model.Empleado;
import org.springframework.data.repository.CrudRepository;
public interface IEmpleado extends CrudRepository<Empleado,Integer>{


}
